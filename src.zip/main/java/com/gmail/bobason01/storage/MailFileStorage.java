package com.gmail.bobason01.storage;

import com.gmail.bobason01.mail.Mail;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MailFileStorage {

    private static final File folder = new File(
            Objects.requireNonNull(Bukkit.getPluginManager().getPlugin("MailManager")).getDataFolder(), "mails");

    private static final Logger logger = Bukkit.getLogger();

    public static void saveAll(Map<UUID, List<Mail>> mailboxes) {
        if (!folder.exists()) folder.mkdirs();

        for (Map.Entry<UUID, List<Mail>> entry : mailboxes.entrySet()) {
            UUID uuid = entry.getKey();
            List<Mail> mails = entry.getValue();

            File file = new File(folder, uuid + ".yml");
            YamlConfiguration config = new YamlConfiguration();

            int index = 0;
            for (Mail mail : mails) {
                String path = "mails." + index++;
                config.set(path + ".sender", mail.sender().toString());
                config.set(path + ".expire", mail.expireAtMillis());
                config.set(path + ".item", mail.item().serialize());
            }

            try {
                config.save(file);
            } catch (IOException e) {
                logger.log(Level.WARNING, "Failed to save mail file: " + file.getName(), e);
            }
        }
    }

    public static Map<UUID, List<Mail>> loadAll() {
        Map<UUID, List<Mail>> loaded = new HashMap<>();
        if (!folder.exists()) return loaded;

        for (File file : Objects.requireNonNull(folder.listFiles())) {
            try {
                UUID uuid = UUID.fromString(file.getName().replace(".yml", ""));
                YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
                List<Mail> list = new ArrayList<>();

                if (config.getConfigurationSection("mails") == null) continue;
                for (String key : Objects.requireNonNull(config.getConfigurationSection("mails")).getKeys(false)) {
                    try {
                        UUID sender = UUID.fromString(Objects.requireNonNull(config.getString("mails." + key + ".sender")));
                        long expire = config.getLong("mails." + key + ".expire");
                        ItemStack item = ItemStack.deserialize(
                                Objects.requireNonNull(config.getConfigurationSection("mails." + key + ".item")).getValues(false));
                        list.add(new Mail(sender, uuid, item, expire));
                    } catch (Exception inner) {
                        logger.log(Level.WARNING, "Failed to parse mail entry: " + key + " in " + file.getName(), inner);
                    }
                }
                loaded.put(uuid, list);
            } catch (Exception e) {
                logger.log(Level.WARNING, "Failed to load mail file: " + file.getName(), e);
            }
        }

        return loaded;
    }
}