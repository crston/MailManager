package com.gmail.bobason01.gui;

import com.gmail.bobason01.MailManager;
import com.gmail.bobason01.mail.MailService;
import com.gmail.bobason01.utils.ConfigLoader;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class MailSendAllGUI implements Listener {

    private Inventory inventory;
    private Player player;

    public MailSendAllGUI(Player player) {
        this.player = player;
    }

    public void open() {
        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();

        String titleKey = config.getString("menus.mail-sendall.title-key");
        String title = LangUtil.get(player.getUniqueId(), titleKey != null ? titleKey : "Send Mail to All");

        int size = config.getInt("menus.mail-sendall.size");

        inventory = Bukkit.createInventory(player, size, title);
        populateInventory();
        player.openInventory(inventory);
    }

    private void populateInventory() {
        if (player == null || inventory == null) return;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection itemsSection = config.getConfigurationSection("menus.mail-sendall.items");
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail-sendall.items");

        if (itemsSection == null || slotsSection == null) return;

        for (String key : itemsSection.getKeys(false)) {
            ConfigurationSection itemConfig = itemsSection.getConfigurationSection(key);
            if (itemConfig != null) {
                ItemStack item = LangUtil.itemFromConfig(itemConfig, player.getUniqueId());
                int slot = slotsSection.getInt(key, -1);
                if (slot != -1) {
                    inventory.setItem(slot, item);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        if (!event.getInventory().equals(inventory)) return;
        event.setCancelled(true);

        ItemStack clickedItem = event.getCurrentItem();
        if (clickedItem == null || clickedItem.getType() == Material.AIR) return;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail-sendall.items");
        if (slotsSection == null) return;

        int slot = event.getRawSlot();

        if (slot == slotsSection.getInt("send", -1)) {
            // 아이템을 가져옵니다.
            int itemSlot = slotsSection.getInt("item", 4);
            ItemStack itemToSend = inventory.getItem(itemSlot);

            // 아이템이 없으면 에러 메시지를 보냅니다.
            if (itemToSend == null || itemToSend.getType() == Material.AIR) {
                player.sendMessage(LangUtil.get(player.getUniqueId(), "message.send.no-item"));
                return;
            }
            // 모든 플레이어에게 메일을 보냅니다.
            for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
                MailService.sendMail(player.getUniqueId(), onlinePlayer.getUniqueId(), itemToSend.clone(), -1);
            }

            // 성공 메시지를 보냅니다.
            player.sendMessage(LangUtil.get(player.getUniqueId(), "message.sendall.success"));
            player.closeInventory();
        }
    }
}