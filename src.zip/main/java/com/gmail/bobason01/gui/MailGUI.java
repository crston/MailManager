package com.gmail.bobason01.gui;

import com.gmail.bobason01.MailManager;
import com.gmail.bobason01.mail.Mail;
import com.gmail.bobason01.mail.MailService;
import com.gmail.bobason01.utils.ConfigLoader;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

public class MailGUI implements Listener {

    private Inventory inventory;
    private Player player;

    public void open(Player player) {
        this.player = player;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();

        String titleKey = config.getString("menus.mail.title-key");
        String title = LangUtil.get(player.getUniqueId(), titleKey != null ? titleKey : "Mailbox");

        int size = config.getInt("menus.mail.size");

        inventory = Bukkit.createInventory(player, size, title);
        populateInventory();
        player.openInventory(inventory);
    }

    private void populateInventory() {
        if (player == null || inventory == null) return;

        UUID uuid = player.getUniqueId();
        List<Mail> inbox = MailService.getInbox(uuid);

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection itemsSection = config.getConfigurationSection("menus.mail.items");
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail.items");

        int itemSlot = 0;
        for (Mail mail : inbox) {
            ItemStack itemStack = mail.getItem().clone();
            ItemMeta meta = itemStack.getItemMeta();
            if (meta != null) {
                String senderName = Bukkit.getOfflinePlayer(mail.getSender()).getName();
                meta.setDisplayName(LangUtil.get(uuid, "gui.mail.item.title").replace("%sender%", senderName != null ? senderName : "Unknown"));

                List<String> lore = List.of(
                        LangUtil.get(uuid, "gui.mail.item.lore.received"),
                        LangUtil.get(uuid, "gui.mail.item.lore.expires").replace("%time%", formatMillis(mail.getExpireAtMillis() - System.currentTimeMillis()))
                );
                meta.setLore(lore);
                itemStack.setItemMeta(meta);
            }
            inventory.setItem(itemSlot++, itemStack);
            if (itemSlot >= inventory.getSize() - 9) break;
        }

        if (itemsSection != null && slotsSection != null) {
            for (String key : itemsSection.getKeys(false)) {
                ConfigurationSection itemConfig = itemsSection.getConfigurationSection(key);
                if (itemConfig != null) {
                    ItemStack item = LangUtil.itemFromConfig(itemConfig, uuid);
                    int slot = slotsSection.getInt(key, -1);
                    if (slot != -1) {
                        inventory.setItem(slot, item);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        if (!event.getInventory().equals(inventory)) return;
        event.setCancelled(true);

        ItemStack clickedItem = event.getCurrentItem();
        if (clickedItem == null || clickedItem.getType() == Material.AIR) return;

        int slot = event.getRawSlot();

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail.items");

        if (slotsSection == null) return;
        if (slot == slotsSection.getInt("settings", -1)) {
            new MailSettingGUI(player).open();
        } else if (slot == slotsSection.getInt("send", -1)) {
            new MailSendGUI(player).open();
        }  else {
            List<Mail> inbox = MailService.getInbox(player.getUniqueId());
            if (slot >= 0 && slot < inbox.size()) {
                Mail mail = inbox.get(slot);
                if (mail == null) return;

                if (event.isShiftClick() && event.getClick().isRightClick()) {
                    MailService.removeMail(player.getUniqueId(), mail);
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.mail.deleted"));
                    open(player);
                    return;
                }

                if (mail.isExpired()) {
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.mail.expired"));
                    return;
                }

                if (player.getInventory().firstEmpty() == -1) {
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.mail.full"));
                    return;
                }

                player.getInventory().addItem(mail.getItem());
                MailService.removeMail(player.getUniqueId(), mail);
                player.sendMessage(LangUtil.get(player.getUniqueId(), "message.mail.received"));
                open(player);
                return;
            }
        }
    }

    private String formatMillis(long millis) {
        long seconds = millis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;

        if (days > 0) {
            return days + "d";
        } else if (hours > 0) {
            return hours + "h";
        } else if (minutes > 0) {
            return minutes + "m";
        } else {
            return "방금 전";
        }
    }
}