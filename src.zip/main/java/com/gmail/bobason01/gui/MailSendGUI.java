package com.gmail.bobason01.gui;

import com.gmail.bobason01.MailManager;
import com.gmail.bobason01.mail.MailService;
import com.gmail.bobason01.utils.ChatListener;
import com.gmail.bobason01.utils.ConfigLoader;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

public class MailSendGUI implements Listener {

    private Inventory inventory;
    private Player player;
    private UUID targetUUID;
    private Long expireTime;

    public MailSendGUI(Player player) {
        this.player = player;
        this.targetUUID = null;
        this.expireTime = null;
    }

    public void open() {
        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();

        String titleKey = config.getString("menus.mail-send.title-key");
        String title = LangUtil.get(player.getUniqueId(), titleKey != null ? titleKey : "Send Mail");

        int size = config.getInt("menus.mail-send.size");

        inventory = Bukkit.createInventory(player, size, title);
        populateInventory();
        player.openInventory(inventory);
    }

    private void populateInventory() {
        if (player == null || inventory == null) return;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection itemsSection = config.getConfigurationSection("menus.mail-send.items");
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail-send.items");

        if (itemsSection == null || slotsSection == null) return;

        for (String key : itemsSection.getKeys(false)) {
            ConfigurationSection itemConfig = itemsSection.getConfigurationSection(key);
            if (itemConfig != null) {
                ItemStack item = LangUtil.itemFromConfig(itemConfig, player.getUniqueId());
                int slot = slotsSection.getInt(key, -1);
                if (slot != -1) {
                    inventory.setItem(slot, item);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        if (!event.getInventory().equals(inventory)) return;
        event.setCancelled(true);

        ItemStack clickedItem = event.getCurrentItem();
        if (clickedItem == null || clickedItem.getType() == Material.AIR) return;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail-send.items");
        if (slotsSection == null) return;

        int slot = event.getRawSlot();

        if (slot == slotsSection.getInt("target", -1)) {
            player.closeInventory();
            player.sendMessage(LangUtil.get(player.getUniqueId(), "gui.target.prompt"));
            ChatListener.setPlayerWaitingForTarget(player, (targetName) -> {
                Player target = Bukkit.getPlayer(targetName);
                if (target != null) {
                    this.targetUUID = target.getUniqueId();
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.target.selected").replace("%name%", target.getName()));
                } else {
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.target.not-found").replace("%name%", targetName));
                }
                this.open();
            });
        } else if (slot == slotsSection.getInt("time", -1)) {
            player.closeInventory();
            player.sendMessage(LangUtil.get(player.getUniqueId(), "gui.time.prompt"));
            ChatListener.setPlayerWaitingForTime(player, (time) -> {
                try {
                    this.expireTime = Long.parseLong(time);
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.time.success").replace("%time%", time));
                } catch (NumberFormatException e) {
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.time.invalid"));
                }
                this.open();
            });

        } else if (slot == slotsSection.getInt("send", -1)) {
            if (targetUUID == null) {
                player.sendMessage(LangUtil.get(player.getUniqueId(), "message.send.no-target"));
                return;
            }

            int itemSlot = slotsSection.getInt("item", 15);
            ItemStack itemToSend = inventory.getItem(itemSlot);

            if (itemToSend == null || itemToSend.getType() == Material.AIR) {
                player.sendMessage(LangUtil.get(player.getUniqueId(), "message.send.no-item"));
                return;
            }

            long expiration = (expireTime != null) ? System.currentTimeMillis() + expireTime : -1;
            MailService.sendMail(player.getUniqueId(), targetUUID, itemToSend.clone(), expiration);
            player.sendMessage(LangUtil.get(player.getUniqueId(), "message.send.success"));
            player.closeInventory();
        } else if (slot == slotsSection.getInt("back", -1)) {
            new MailGUI().open(player);
        }
    }
}