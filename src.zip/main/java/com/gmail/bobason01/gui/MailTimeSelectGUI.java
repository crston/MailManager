package com.gmail.bobason01.gui;

import com.gmail.bobason01.utils.ItemBuilder;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Calendar;
import java.util.UUID;

public class MailTimeSelectGUI implements Listener {

    private final Player player;
    private final MailSendGUI parent;
    private final Inventory gui;

    private int year, month, day, hour, minute, second;

    public MailTimeSelectGUI(Player player, MailSendGUI parent) {
        this.player = player;
        this.parent = parent;

        UUID uuid = player.getUniqueId();
        FileConfiguration config = LangUtil.getConfig();
        String title = LangUtil.get(uuid, config.getString("menus.mail-time.title-key"));
        int size = config.getInt("menus.mail-time.size");

        this.gui = Bukkit.createInventory(null, size, title);

        Calendar now = Calendar.getInstance();
        this.year = now.get(Calendar.YEAR);
        this.month = now.get(Calendar.MONTH) + 1;
        this.day = now.get(Calendar.DAY_OF_MONTH);
        this.hour = 0;
        this.minute = 0;
        this.second = 0;

        updateItems();
        player.openInventory(gui);
    }

    private void updateItems() {
        UUID uuid = player.getUniqueId();
        FileConfiguration config = LangUtil.getConfig();
        ConfigurationSection slots = config.getConfigurationSection("menus.mail-time.slots");
        ConfigurationSection items = config.getConfigurationSection("menus.mail-time.items");

        gui.setItem(slots.getInt("second"), timeItem(uuid, "second", second));
        gui.setItem(slots.getInt("minute"), timeItem(uuid, "minute", minute));
        gui.setItem(slots.getInt("hour"), timeItem(uuid, "hour", hour));
        gui.setItem(slots.getInt("day"), timeItem(uuid, "day", day));
        gui.setItem(slots.getInt("month"), timeItem(uuid, "month", month));
        gui.setItem(slots.getInt("year"), timeItem(uuid, "year", year));

        gui.setItem(slots.getInt("permanent"), LangUtil.itemFromConfig(items.getConfigurationSection("permanent"), uuid));
        gui.setItem(slots.getInt("confirm"), LangUtil.itemFromConfig(items.getConfigurationSection("confirm"), uuid));
        gui.setItem(slots.getInt("back"), LangUtil.itemFromConfig(items.getConfigurationSection("back"), uuid));
    }

    private ItemStack timeItem(UUID uuid, String unit, int value) {
        String name = LangUtil.get(uuid, "gui.time.unit." + unit).replace("%value%", String.valueOf(value));
        String left = LangUtil.get(uuid, "gui.time.lore.left");
        String right = LangUtil.get(uuid, "gui.time.lore.right");
        return ItemBuilder.create(Material.CLOCK, name, left, right);
    }

    @EventHandler
    public void handleClick(InventoryClickEvent e) {
        if (!e.getView().getTopInventory().equals(gui)) return;

        e.setCancelled(true);
        UUID uuid = player.getUniqueId();
        FileConfiguration config = LangUtil.getConfig();
        ConfigurationSection slots = config.getConfigurationSection("menus.mail-time.slots");

        int slot = e.getRawSlot();
        int delta = e.isLeftClick() ? -1 : 1;

        if (slot == slots.getInt("second")) second = clamp(second + delta, 0, 59);
        else if (slot == slots.getInt("minute")) minute = clamp(minute + delta, 0, 59);
        else if (slot == slots.getInt("hour")) hour = clamp(hour + delta, 0, 23);
        else if (slot == slots.getInt("day")) day = clamp(day + delta, 1, 31);
        else if (slot == slots.getInt("month")) month = clamp(month + delta, 1, 12);
        else if (slot == slots.getInt("year")) year = clamp(year + delta, 1970, 2100);
        else if (slot == slots.getInt("permanent")) {
            parent.setExpireTime(-1);
            player.sendMessage(LangUtil.get(uuid, "message.time.permanent"));
            new MailSendGUI(player);
            return;
        } else if (slot == slots.getInt("confirm")) {
            Calendar cal = Calendar.getInstance();
            cal.set(year, month - 1, day, hour, minute, second);
            long millis = cal.getTimeInMillis();
            if (millis < System.currentTimeMillis()) {
                player.sendMessage(LangUtil.get(uuid, "message.time.past"));
                return;
            }
            parent.setExpireTime(millis);
            player.sendMessage(LangUtil.get(uuid, "message.time.success"));
            new MailSendGUI(player);
            return;
        } else if (slot == slots.getInt("back")) {
            new MailSendGUI(player);
            return;
        }

        updateItems();
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    public Inventory getInventory() {
        return gui;
    }
}