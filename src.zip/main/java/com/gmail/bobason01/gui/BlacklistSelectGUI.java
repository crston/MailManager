package com.gmail.bobason01.gui;

import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public class BlacklistSelectGUI implements Listener {

    private static final Map<UUID, Set<UUID>> blacklist = new HashMap<>();

    private final Player viewer;
    private final Inventory gui;

    public BlacklistSelectGUI(Player viewer) {
        this.viewer = viewer;

        FileConfiguration config = LangUtil.getConfig();
        String title = LangUtil.get(viewer.getUniqueId(), config.getString("gui.blacklist.title"));
        int size = config.getInt("gui.blacklist.size");

        this.gui = Bukkit.createInventory(null, size, title);
        update();
        viewer.openInventory(gui);
    }

    public void update() {
        UUID viewerUUID = viewer.getUniqueId();
        Set<UUID> blocked = blacklist.getOrDefault(viewerUUID, new HashSet<>());
        OfflinePlayer[] all = Bukkit.getOfflinePlayers();
        int slot = 10;

        for (OfflinePlayer target : all) {
            if (slot >= 44) break;
            if (target.getUniqueId().equals(viewerUUID)) continue;

            ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) skull.getItemMeta();
            if (meta == null) continue;
            meta.setOwningPlayer(target);
            meta.setDisplayName(target.getName());
            List<String> lore = new ArrayList<>();
            if (blocked.contains(target.getUniqueId())) {
                lore.add(LangUtil.get(viewerUUID, "gui.blacklist.status.blocked"));
            } else {
                lore.add(LangUtil.get(viewerUUID, "gui.blacklist.status.allowed"));
            }
            meta.setLore(lore);
            skull.setItemMeta(meta);
            gui.setItem(slot++, skull);
        }
    }

    public static boolean isBlocked(UUID viewer, UUID target) {
        return blacklist.getOrDefault(viewer, Collections.emptySet()).contains(target);
    }

    public static void toggle(UUID viewer, UUID target) {
        blacklist.putIfAbsent(viewer, new HashSet<>());
        Set<UUID> list = blacklist.get(viewer);
        if (!list.add(target)) list.remove(target);
    }

    @EventHandler
    public void handleClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (!e.getView().getTopInventory().equals(gui)) return;
        e.setCancelled(true);

        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.getType().equals(Material.PLAYER_HEAD)) return;
        SkullMeta meta = (SkullMeta) clicked.getItemMeta();
        if (meta == null) return;
        OfflinePlayer target = meta.getOwningPlayer();
        if (target == null) return;

        toggle(viewer.getUniqueId(), target.getUniqueId());
        update();
    }

    public Inventory getInventory() {
        return gui;
    }
}