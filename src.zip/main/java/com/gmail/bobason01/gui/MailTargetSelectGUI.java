package com.gmail.bobason01.gui;

import com.gmail.bobason01.utils.ChatSearchRegistry;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class MailTargetSelectGUI implements Listener {

    private final Player viewer;
    private final MailSendGUI parent;
    private final Inventory gui;
    private final List<OfflinePlayer> allPlayers;

    public MailTargetSelectGUI(Player viewer, MailSendGUI parent) {
        this.viewer = viewer;
        this.parent = parent;
        this.allPlayers = Arrays.asList(Bukkit.getOfflinePlayers());

        FileConfiguration config = LangUtil.getConfig();
        String title = LangUtil.get(viewer.getUniqueId(), config.getString("menus.mail-target.title-key"));
        int size = config.getInt("menus.mail-target.size");

        this.gui = Bukkit.createInventory(null, size, title);
        updateItems();
        viewer.openInventory(gui);
    }

    private void updateItems() {
        UUID self = viewer.getUniqueId();
        FileConfiguration config = LangUtil.getConfig();
        ConfigurationSection items = config.getConfigurationSection("menus.mail-target.items");
        ConfigurationSection slots = config.getConfigurationSection("menus.mail-target.slots");

        int index = 10;

        for (OfflinePlayer target : allPlayers) {
            if (target.getUniqueId().equals(self)) continue;

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(target);
                meta.setDisplayName("§f" + target.getName());
                meta.setLore(List.of(LangUtil.get(self, "gui.target.select")));
                head.setItemMeta(meta);
            }

            gui.setItem(index++, head);
            if (index == 17 || index == 26 || index == 35) index += 2;
        }

        gui.setItem(slots.getInt("search"), LangUtil.itemFromConfig(items.getConfigurationSection("search"), self));
        gui.setItem(slots.getInt("back"), LangUtil.itemFromConfig(items.getConfigurationSection("back"), self));
    }

    @EventHandler
    public void handleClick(InventoryClickEvent e) {
        if (!e.getView().getTopInventory().equals(gui)) return;
        e.setCancelled(true);
        int slot = e.getRawSlot();
        UUID self = viewer.getUniqueId();
        FileConfiguration config = LangUtil.getConfig();
        ConfigurationSection slots = config.getConfigurationSection("menus.mail-target.slots");

        if (slot >= 10 && slot <= 43) {
            ItemStack clicked = gui.getItem(slot);
            if (clicked != null && clicked.getType() == Material.PLAYER_HEAD) {
                SkullMeta meta = (SkullMeta) clicked.getItemMeta();
                if (meta != null && meta.getOwningPlayer() != null) {
                    UUID uuid = meta.getOwningPlayer().getUniqueId();
                    parent.setTarget(uuid);
                    viewer.sendMessage(LangUtil.get(self, "message.target.selected")
                            .replace("%name%", Objects.requireNonNull(meta.getOwningPlayer().getName())));
                    new MailSendGUI(viewer);
                }
            }
        } else {
            if (slot == slots.getInt("search")) {
                viewer.closeInventory();
                viewer.sendMessage(LangUtil.get(self, "gui.target.chat-prompt"));
                ChatSearchRegistry.startSearch(viewer.getUniqueId(), name -> {
                    OfflinePlayer found = Arrays.stream(Bukkit.getOfflinePlayers())
                            .filter(p -> p.getName() != null && p.getName().equalsIgnoreCase(name))
                            .findFirst()
                            .orElse(null);

                    if (found != null) {
                        parent.setTarget(found.getUniqueId());
                        viewer.sendMessage(LangUtil.get(self, "message.target.selected")
                                .replace("%name%", Objects.requireNonNull(found.getName())));
                    } else {
                        viewer.sendMessage(LangUtil.get(self, "message.target.not-found").replace("%name%", name));
                    }

                    new MailSendGUI(viewer);
                });
            } else if (slot == slots.getInt("back")) {
                new MailSendGUI(viewer);
            }
        }
    }

    public Inventory getInventory() {
        return gui;
    }
}