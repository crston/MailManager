package com.gmail.bobason01.gui;

import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public class SendAllExcludeGUI implements Listener {

    private final Player viewer;
    private final MailSendAllGUI parent;
    private final Set<UUID> excluded;
    private final Inventory gui;
    private final List<OfflinePlayer> allPlayers;

    public SendAllExcludeGUI(Player viewer, MailSendAllGUI parent, Set<UUID> excluded) {
        this.viewer = viewer;
        this.parent = parent;
        this.excluded = excluded;

        FileConfiguration config = LangUtil.getConfig();
        String title = LangUtil.get(viewer.getUniqueId(), config.getString("menus.mail-exclude.title-key"));
        int size = config.getInt("menus.mail-exclude.size");

        this.gui = Bukkit.createInventory(null, size, title);
        this.allPlayers = Arrays.asList(Bukkit.getOfflinePlayers());

        updateItems();
        viewer.openInventory(gui);
    }

    private void updateItems() {
        UUID self = viewer.getUniqueId();
        int index = 10;
        FileConfiguration config = LangUtil.getConfig();

        for (OfflinePlayer target : allPlayers) {
            if (target.getUniqueId().equals(self)) continue;

            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            if (meta != null) {
                meta.setOwningPlayer(target);
                meta.setDisplayName("§f" + target.getName());

                boolean isExcluded = excluded.contains(target.getUniqueId());
                String status = LangUtil.get(self, isExcluded ? "gui.exclude.status.excluded" : "gui.exclude.status.included");
                String action = LangUtil.get(self, isExcluded ? "gui.exclude.include" : "gui.exclude.exclude");

                meta.setLore(List.of(status, LangUtil.get(self, "gui.exclude.toggle").replace("%action%", action)));
                head.setItemMeta(meta);
            }

            gui.setItem(index++, head);
            if (index == 17 || index == 26 || index == 35) index += 2;
        }

        ConfigurationSection items = config.getConfigurationSection("menus.mail-exclude.items");
        ConfigurationSection slots = config.getConfigurationSection("menus.mail-exclude.slots");

        if (items != null && slots != null) {
            gui.setItem(slots.getInt("back"), LangUtil.itemFromConfig(items.getConfigurationSection("back"), self));
        }
    }

    @EventHandler
    public void handleClick(InventoryClickEvent e) {
        if (!e.getView().getTopInventory().equals(gui)) return;
        e.setCancelled(true);

        int slot = e.getRawSlot();
        UUID self = viewer.getUniqueId();
        FileConfiguration config = LangUtil.getConfig();
        ConfigurationSection slots = config.getConfigurationSection("menus.mail-exclude.slots");

        if (slot >= 10 && slot <= 43) {
            ItemStack clicked = gui.getItem(slot);
            if (clicked == null || clicked.getType() != Material.PLAYER_HEAD) return;

            SkullMeta meta = (SkullMeta) clicked.getItemMeta();
            if (meta == null || meta.getOwningPlayer() == null) return;

            UUID target = meta.getOwningPlayer().getUniqueId();
            if (excluded.contains(target)) {
                excluded.remove(target);
                viewer.sendMessage(LangUtil.get(self, "message.exclude.include").replace("%name%", Objects.requireNonNull(meta.getOwningPlayer().getName())));
            } else {
                excluded.add(target);
                viewer.sendMessage(LangUtil.get(self, "message.exclude.exclude").replace("%name%", Objects.requireNonNull(meta.getOwningPlayer().getName())));
            }

            updateItems();
        } else {
            if (slot == slots.getInt("back")) {
                parent.reopen();
            }
        }
    }

    public Inventory getInventory() {
        return gui;
    }
}