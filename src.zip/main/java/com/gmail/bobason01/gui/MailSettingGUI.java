package com.gmail.bobason01.gui;

import com.gmail.bobason01.MailManager;
import com.gmail.bobason01.utils.ConfigLoader;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class MailSettingGUI implements Listener {

    private Inventory inventory;
    private Player player;

    public MailSettingGUI(Player player) {
        this.player = player;
    }

    public void open() {
        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();

        String titleKey = config.getString("menus.mail-setting.title-key");
        String title = LangUtil.get(player.getUniqueId(), titleKey != null ? titleKey : "Mail Settings");

        int size = config.getInt("menus.mail-setting.size");

        inventory = Bukkit.createInventory(player, size, title);
        populateInventory();
        player.openInventory(inventory);
    }

    private void populateInventory() {
        if (player == null || inventory == null) return;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection itemsSection = config.getConfigurationSection("menus.mail-setting.items");
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail-setting.slots");

        if (itemsSection == null || slotsSection == null) return;

        for (String key : itemsSection.getKeys(false)) {
            ConfigurationSection itemConfig = itemsSection.getConfigurationSection(key);
            if (itemConfig != null) {
                ItemStack item = LangUtil.itemFromConfig(itemConfig, player.getUniqueId());
                int slot = slotsSection.getInt(key, -1);
                if (slot != -1) {
                    inventory.setItem(slot, item);
                }
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        if (!event.getInventory().equals(inventory)) return;
        event.setCancelled(true);

        ItemStack clickedItem = event.getCurrentItem();
        if (clickedItem == null || clickedItem.getType() == Material.AIR) return;

        ConfigLoader configLoader = MailManager.getInstance().getConfigLoader();
        FileConfiguration config = configLoader.getConfig();
        ConfigurationSection slotsSection = config.getConfigurationSection("menus.mail-setting.slots");
        if (slotsSection == null) return;

        int slot = event.getRawSlot();

        if (slot == slotsSection.getInt("back", -1)) {
            new MailGUI().open(player);
        }
    }
}