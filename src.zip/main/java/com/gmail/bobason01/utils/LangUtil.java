package com.gmail.bobason01.utils;

import com.gmail.bobason01.MailManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Level;

public class LangUtil {

    private static final Map<String, FileConfiguration> languages = new HashMap<>();
    private static String defaultLanguage = "en_us";

    public static void load(File dataFolder) {
        File langFolder = new File(dataFolder, "lang");
        if (!langFolder.exists()) {
            langFolder.mkdirs();
        }

        // Load default language file if it doesn't exist
        File defaultLangFile = new File(langFolder, defaultLanguage + ".yml");
        if (!defaultLangFile.exists()) {
            try (InputStream inputStream = MailManager.getInstance().getResource("lang/" + defaultLanguage + ".yml")) {
                if (inputStream != null) {
                    YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
                    defaultConfig.save(defaultLangFile);
                } else {
                    defaultLangFile.createNewFile();
                }
                MailManager.getInstance().getLogger().info("Created default language file: " + defaultLanguage + ".yml");
            } catch (IOException e) {
                MailManager.getInstance().getLogger().log(Level.SEVERE, "Could not create default language file.", e);
            }
        }

        // Load all language files
        for (File file : Objects.requireNonNull(langFolder.listFiles((dir, name) -> name.endsWith(".yml")))) {
            String code = file.getName().replace(".yml", "");
            languages.put(code, YamlConfiguration.loadConfiguration(file));
            MailManager.getInstance().getLogger().info("Loaded language file: " + code + ".yml");
        }
    }

    public static String get(UUID uuid, String key) {
        String lang = defaultLanguage; // 기본 언어 설정
        if (uuid != null) {
            // 플레이어별 언어 설정 기능이 있다면 여기서 가져옴
        }
        FileConfiguration config = languages.get(lang);
        if (config == null) {
            return key; // 언어 파일이 없으면 키를 그대로 반환
        }
        return config.getString(key, key); // 값이 없으면 키를 그대로 반환
    }

    public static ItemStack itemFromConfig(ConfigurationSection section, UUID uuid) {
        if (section == null) {
            return new ItemStack(Material.AIR);
        }

        String materialStr = section.getString("material", "STONE").toUpperCase();
        Material material = Material.getMaterial(materialStr);
        if (material == null) {
            material = Material.STONE;
            MailManager.getInstance().getLogger().warning("Invalid material: " + materialStr);
        }

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();

        if (meta != null) {
            String nameKey = section.getString("name");
            if (nameKey != null) {
                meta.setDisplayName(LangUtil.get(uuid, nameKey));
            }

            List<String> loreKeys = section.getStringList("lore");
            if (!loreKeys.isEmpty()) {
                List<String> lore = new ArrayList<>();
                for (String loreKey : loreKeys) {
                    lore.add(LangUtil.get(uuid, loreKey));
                }
                meta.setLore(lore);
            }

            if (section.contains("skull-owner") && material == Material.PLAYER_HEAD) {
                String skullOwner = section.getString("skull-owner");
                if (skullOwner != null && meta instanceof SkullMeta) {
                    OfflinePlayer player = Bukkit.getOfflinePlayer(skullOwner);
                    ((SkullMeta) meta).setOwningPlayer(player);
                }
            }

            item.setItemMeta(meta);
        }

        return item;
    }
}