package com.gmail.bobason01.utils;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

public class ItemBuilder {

    /**
     * 간단한 아이템 생성 유틸 (이름만 지정)
     */
    public static ItemStack create(Material material, String displayName) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(displayName);
        item.setItemMeta(meta);
        return item;
    }

    /**
     * 아이템 이름 + 로어 지정
     */
    public static ItemStack create(Material material, String displayName, String... lore) {
        return create(material, displayName, Arrays.asList(lore));
    }

    /**
     * 아이템 이름 + 로어 지정 (List 버전)
     */
    public static ItemStack create(Material material, String displayName, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        meta.setDisplayName(displayName);
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
}