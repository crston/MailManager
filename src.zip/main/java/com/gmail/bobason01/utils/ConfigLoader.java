package com.gmail.bobason01.utils;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import com.gmail.bobason01.MailManager;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public class ConfigLoader {

    private final MailManager plugin;
    private FileConfiguration config;

    public ConfigLoader(MailManager plugin) {
        this.plugin = plugin;
    }

    public void loadConfigs() {
        File configFile = new File(plugin.getDataFolder(), "config.yml");
        if (!configFile.exists()) {
            configFile.getParentFile().mkdirs();
            plugin.getLogger().info("Creating default config.yml...");
            try (InputStream inputStream = plugin.getResource("config.yml")) {
                if (inputStream != null) {
                    YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
                    defaultConfig.save(configFile);
                    plugin.getLogger().info("Default config.yml created.");
                } else {
                    try {
                        configFile.createNewFile();
                    } catch (IOException e) {
                        plugin.getLogger().log(Level.SEVERE, "Could not create config.yml", e);
                    }
                }
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not create config.yml", e);
            }
        }
        config = YamlConfiguration.loadConfiguration(configFile);
    }

    public void reloadConfigs() {
        File configFile = new File(plugin.getDataFolder(), "config.yml");
        config = YamlConfiguration.loadConfiguration(configFile);
        plugin.getLogger().info("Config reloaded.");
    }

    public FileConfiguration getConfig() {
        return config;
    }
}