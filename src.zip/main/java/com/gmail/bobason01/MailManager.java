package com.gmail.bobason01;

import com.gmail.bobason01.commands.MailCommand;
import com.gmail.bobason01.gui.MailGUI;
import com.gmail.bobason01.listeners.ChatListener;
import com.gmail.bobason01.mail.MailService;
import com.gmail.bobason01.utils.ConfigLoader;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public class MailManager extends JavaPlugin {

    private static MailManager instance;
    private ConfigLoader configLoader;

    public static MailManager getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        // ConfigLoader 초기화
        configLoader = new ConfigLoader(this);
        configLoader.loadConfigs();

        // LangUtil 로드
        LangUtil.load(getDataFolder());

        // MailService 로드
        MailService.loadAllFromDisk();

        // 명령어 등록
        Objects.requireNonNull(getCommand("mail")).setExecutor(new MailCommand());
        Objects.requireNonNull(getCommand("mail")).setTabCompleter(new MailCommand());

        // 이벤트 리스너 등록
        Bukkit.getPluginManager().registerEvents(new MailGUI(), this);
        Bukkit.getPluginManager().registerEvents(new ChatListener(), this);

        getLogger().info("MailManager has been enabled!");
    }

    @Override
    public void onDisable() {
        // MailService 저장
        MailService.saveAllToDisk();

        getLogger().info("MailManager has been disabled!");
    }

    public ConfigLoader getConfigLoader() {
        return configLoader;
    }
}