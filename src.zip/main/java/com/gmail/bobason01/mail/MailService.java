package com.gmail.bobason01.mail;

import com.gmail.bobason01.MailManager;
import com.gmail.bobason01.utils.ConfigLoader;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public class MailService {

    private static final Map<UUID, List<Mail>> mailbox = new HashMap<>();

    public static void sendMail(UUID sender, UUID receiver, ItemStack item, long expireAtMillis) {
        Mail mail = new Mail(sender, receiver, item, expireAtMillis);
        mailbox.computeIfAbsent(receiver, k -> new ArrayList<>()).add(mail);

        Player receiverPlayer = Bukkit.getPlayer(receiver);
        if (receiverPlayer != null) {
            String message = LangUtil.get(receiver, "message.mail.received");
            receiverPlayer.sendMessage(message);
        }
    }

    public static List<Mail> getInbox(UUID receiver) {
        List<Mail> inbox = mailbox.getOrDefault(receiver, new ArrayList<>());
        inbox.removeIf(Mail::isExpired);
        return inbox;
    }

    public static void removeMail(UUID receiver, Mail mail) {
        List<Mail> inbox = mailbox.get(receiver);
        if (inbox != null) {
            inbox.remove(mail);
        }
    }

    public static void loadAllFromDisk() {
        File dataFolder = MailManager.getInstance().getDataFolder();
        File mailFolder = new File(dataFolder, "mail");
        if (!mailFolder.exists()) {
            mailFolder.mkdirs();
        }

        mailbox.clear();
        for (File file : mailFolder.listFiles()) {
            if (file.isFile() && file.getName().endsWith(".yml")) {
                UUID receiver = UUID.fromString(file.getName().replace(".yml", ""));
                loadMailbox(receiver, file);
            }
        }
    }

    private static void loadMailbox(UUID receiver, File file) {
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        List<Mail> mailList = new ArrayList<>();
        ConfigurationSection mailSection = config.getConfigurationSection("mail");
        if (mailSection != null) {
            for (String key : mailSection.getKeys(false)) {
                try {
                    UUID sender = UUID.fromString(mailSection.getString(key + ".sender"));
                    ItemStack item = config.getItemStack(key + ".item");
                    long expireAtMillis = config.getLong(key + ".expireAtMillis");
                    Mail mail = new Mail(sender, receiver, item, expireAtMillis);
                    mailList.add(mail);
                } catch (Exception e) {
                    MailManager.getInstance().getLogger().log(Level.WARNING, "Failed to load mail " + key + " from " + file.getName(), e);
                }
            }
        }
        mailbox.put(receiver, mailList);
    }

    public static void saveAllToDisk() {
        File dataFolder = MailManager.getInstance().getDataFolder();
        File mailFolder = new File(dataFolder, "mail");
        if (!mailFolder.exists()) {
            mailFolder.mkdirs();
        }

        for (Map.Entry<UUID, List<Mail>> entry : mailbox.entrySet()) {
            UUID receiver = entry.getKey();
            List<Mail> mailList = entry.getValue();
            File file = new File(mailFolder, receiver.toString() + ".yml");
            saveMailbox(receiver, mailList, file);
        }
    }

    private static void saveMailbox(UUID receiver, List<Mail> mailList, File file) {
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        config.set("mail", null); // Clear existing mail
        int i = 0;
        for (Mail mail : mailList) {
            String key = "mail." + i++;
            config.set(key + ".sender", mail.getSender().toString());
            config.set(key + ".item", mail.getItem());
            config.set(key + ".expireAtMillis", mail.getExpireAtMillis());
        }
        try {
            config.save(file);
        } catch (IOException e) {
            MailManager.getInstance().getLogger().log(Level.WARNING, "Failed to save mailbox for " + receiver, e);
        }
    }
}