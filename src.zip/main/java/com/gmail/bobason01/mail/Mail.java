package com.gmail.bobason01.mail;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class Mail {
    private UUID sender;
    private UUID receiver;
    private ItemStack item;
    private long expireAtMillis;

    public Mail(UUID sender, UUID receiver, ItemStack item, long expireAtMillis) {
        this.sender = sender;
        this.receiver = receiver;
        this.item = item;
        this.expireAtMillis = expireAtMillis;
    }

    public UUID getSender() {
        return sender;
    }

    public UUID getReceiver() {
        return receiver;
    }

    public ItemStack getItem() {
        return item;
    }

    public long getExpireAtMillis() {
        return expireAtMillis;
    }

    public boolean isExpired() {
        return expireAtMillis != -1 && System.currentTimeMillis() > expireAtMillis;
    }
}