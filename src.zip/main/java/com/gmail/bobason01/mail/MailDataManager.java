package com.gmail.bobason01.mail;

import com.gmail.bobason01.gui.BlacklistSelectGUI;
import com.gmail.bobason01.storage.MailFileStorage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class MailDataManager {

    private static final Map<UUID, List<Mail>> mailbox = new HashMap<>();

    public static void sendMail(UUID sender, UUID receiver, ItemStack item, long expireAtMillis) {
        if (BlacklistSelectGUI.isBlocked(receiver, sender)) {
            Player senderPlayer = Bukkit.getPlayer(sender);
            if (senderPlayer != null)
                senderPlayer.sendMessage("§c해당 플레이어는 당신의 메일을 수신하지 않습니다.");
            return;
        }

        Mail mail = new Mail(sender, receiver, item.clone(), expireAtMillis);
        mailbox.computeIfAbsent(receiver, k -> new ArrayList<>()).add(mail);

        Player receiverPlayer = Bukkit.getPlayer(receiver);
        if (receiverPlayer != null)
            receiverPlayer.sendMessage("§6새로운 메일이 도착했습니다.");
    }

    public static List<Mail> getInbox(UUID receiver) {
        List<Mail> inbox = mailbox.getOrDefault(receiver, new ArrayList<>());
        inbox.removeIf(Mail::isExpired);
        return inbox;
    }

    public static void removeMail(UUID receiver, Mail mail) {
        List<Mail> inbox = mailbox.get(receiver);
        if (inbox != null) inbox.remove(mail);
    }

    public static void clearInbox(UUID receiver) {
        mailbox.remove(receiver);
    }

    public static void loadAllFromDisk() {
        mailbox.clear();
        mailbox.putAll(MailFileStorage.loadAll());
    }

    public static void saveAllToDisk() {
        MailFileStorage.saveAll(mailbox);
    }
}
