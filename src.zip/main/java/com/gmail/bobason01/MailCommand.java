package com.gmail.bobason01;

import com.gmail.bobason01.MailManager;
import com.gmail.bobason01.gui.MailGUI;
import com.gmail.bobason01.gui.MailSendAllGUI;
import com.gmail.bobason01.gui.MailSendGUI;
import com.gmail.bobason01.utils.LangUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.ArrayList;

public class MailCommand implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(LangUtil.get(null, "command.only_player"));
            return true;
        }

        if (args.length == 0) {
            new MailGUI().open(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "send":
                new MailSendGUI(player).open();
                break;
            case "sendall":
                if (player.hasPermission("mail.sendall")) {
                    new MailSendAllGUI(player).open();
                } else {
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.no-permission"));
                }
                break;
            case "reload":
                if (player.hasPermission("mail.reload")) {
                    MailManager.getInstance().getConfigLoader().reloadConfigs();
                    LangUtil.load(MailManager.getInstance().getDataFolder());
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.reload.success"));
                } else {
                    player.sendMessage(LangUtil.get(player.getUniqueId(), "message.no-permission"));
                }
                break;
            default:
                player.sendMessage(LangUtil.get(player.getUniqueId(), "command.usage"));
        }

        return true;
    }

    @Nullable
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.add("send");
            completions.add("sendall");
            completions.add("reload");
        }
        return completions;
    }
}